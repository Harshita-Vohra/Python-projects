#Breach Bot Starter Code
breachYear = 2019

#Greets user
print("Hello! I'm Breach Bot.")
userName = input("What is your name? \n ")
print("Nice to meet you " + userName)

#Recounts year of Breach
todaysYear = input("What year is it?\n")
timePassed = int(todaysYear) - breachYear
print("Wow! That means it has been " + str(timePassed) + " years since the Facebook Data Breach!")

#Introduces breach
print("Would you like to learn about the Facebook 2019 Data Breach")
giveInfo = input("Type 'yes' or 'no'\n")

#Explains breach
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) breach details, (b) organization's response, or (c) I would like to hear your reflection")
  topic = input()
  
  if topic.lower() == "a":
    print("In 2019, data from over 533 million Facebook users was scraped using a contact importer tool that was later patched. The leaked information remained available online until 2021, putting users at risk of phishing and other malicious activities.")
  
  elif topic.lower() == "b":
    print("After the 2019 Facebook data breach, the company patched the vulnerability, improved anti-scraping measures, and worked to remove leaked data from the internet. Although they did not directly inform the 533 million affected users, they advised checking HaveIBeenPwned, enabling two-factor authentication, changing passwords, and watching for phishing or suspicious activity.")  
  
  elif topic.lower() == "c":
    break
  
  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")
  
  input("Press enter to continue\n")

#Introduces my take
print("\nI'm exicted to share my perspective with you. Are you ready to hear my take?")
giveInfo = input("Type 'yes' or 'no'\n")

#Shares my take
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) relation to CIA Triad, (b) my reaction, (c) my advice, or (d) none")
  topic = input()

  if topic.lower() == "a":
    print("In this breach, personal data was scraped without users’ permission and collected in massive amounts, which users did not expect. It shows that even public information can be misused if strong security measures and regulations are not in place.")

  elif topic.lower() == "b":
    print("I disagree with the organization’s response because, while they patched the issue and improved anti-scraping measures, they failed to take responsibility for user safety. Instead of directly informing the 533 million affected users, they downplayed the breach by saying it wasn’t a hack, even though users still had a right to know their data was accessed.")  

  elif topic.lower() == "c":
    print("I would convince victims to take action by explaining how hackers can use their personal data, like phone numbers and emails, to trick them into revealing more information, and emphasize the importance of protecting their accounts to prevent future problems. My advice would be to quickly change any reused passwords, enable two-factor authentication on important accounts, stay cautious of phishing emails, and regularly monitor bank account activity for suspicious behavior.")
    
  elif topic.lower() == "d":
    break

  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")

  input("Press enter to continue\n")

#Chatbot ends conversation
print("Thanks for chatting with me, and I hope you learned something new!")